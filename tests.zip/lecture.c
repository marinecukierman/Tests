#include "lecture.h"

absorp lecture(FILE* file_pf, int* file_state){
	// End of file
	*file_state=EOF;
}