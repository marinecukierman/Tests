void integrationTest(char* filename)
{

}