#include "fir.h"

absorp firTest(char* filename){

}