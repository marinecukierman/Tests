#include "define.h"

absorp lecture(FILE* file_pf, int* file_state);
